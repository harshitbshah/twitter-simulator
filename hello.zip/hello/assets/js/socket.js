// NOTE: The contents of this file will only be executed if
// you uncomment its entry in "assets/js/app.js".

// To use Phoenix channels, the first step is to import Socket
// and connect at the socket path in "lib/web/endpoint.ex":
import {Socket} from "phoenix"

let socket = new Socket("/socket", {params: {token: window.userToken}})

// When you connect, you'll often need to authenticate the client.
// For example, imagine you have an authentication plug, `MyAuth`,
// which authenticates the session and assigns a `:current_user`.
// If the current user exists you can assign the user's token in
// the connection for use in the layout.
//
// In your "lib/web/router.ex":
//
//     pipeline :browser do
//       ...
//       plug MyAuth
//       plug :put_user_token
//     end
//
//     defp put_user_token(conn, _) do
//       if current_user = conn.assigns[:current_user] do
//         token = Phoenix.Token.sign(conn, "user socket", current_user.id)
//         assign(conn, :user_token, token)
//       else
//         conn
//       end
//     end
//
// Now you need to pass this token to JavaScript. You can do so
// inside a script tag in "lib/web/templates/layout/app.html.eex":
//
//     <script>window.userToken = "<%= assigns[:user_token] %>";</script>
//
// You will need to verify the user token in the "connect/2" function
// in "lib/web/channels/user_socket.ex":
//
//     def connect(%{"token" => token}, socket) do
//       # max_age: 1209600 is equivalent to two weeks in seconds
//       case Phoenix.Token.verify(socket, "user socket", token, max_age: 1209600) do
//         {:ok, user_id} ->
//           {:ok, assign(socket, :user, user_id)}
//         {:error, reason} ->
//           :error
//       end
//     end
//
// Finally, pass the token on connect as below. Or remove it
// from connect if you don't care about authentication.

socket.connect()

// Now that you are connected, you can join channels with a topic:
let channel = socket.channel("room:lobby", {})
let list    = $('#message-list');
let password = $('#password');
let name    = $('#name');
let login= $('#login')
let register= $('#register')
let sendtweetlist= $('#send-tweet-list')
let tweetbtn =$('#sendtweetbtn')
let tweetbox = $('#tweetbox')
let followbtn= $('#follow')
let followtxt=$('#followtext')
let homepagediv =$('#loggedin')
let signupdiv =$('#signup')
let searchhashtagtext=$('#searchhashtag')
let searchhashtagbtn=$('#searchhashtagbtn')
let searchusernametxt= $('#searchusername')
let searchusernamebtn= $('#searchusernamebtn')
let retweetusernametxt=$('#retweetusername')
let retweettxt=$('#retweettxt')
let retweetbtn=$('#retweetbtn')
let logoutbtn=$('#logoutbtn')
let loggedinuser=name.val()

var session_key = "";
var user_id = "";
searchhashtagbtn.on('click', event => {   
  channel.push('search_hash_tag', { sessionKey: session_key, userId: user_id, hashTag: searchhashtagtext.val()}); 
  searchhashtagtext.val('');
}
);
  
searchusernamebtn.on('click', event => {
  channel.push('search_mentions', { sessionKey: session_key, userId: user_id, mention: searchusernametxt.val()});
  searchusernametxt.val('');
}
);
  
retweetbtn.on('click', event => {  
  channel.push('retweet', { sessionKey: session_key, userId: user_id, msgId: retweettxt.val()});
  retweettxt.val('');
}
);

tweetbtn.on('click', event => {
  console.log(session_key + " " + user_id + " " + tweetbox.val());
  channel.push('tweet', { sessionKey: session_key, userId: user_id, tweet: tweetbox.val()});
  tweetbox.val('');
}
);

login.on('click', event => {
    channel.push('login', { user_name: name.val(), password: password.val() });
  }
);

register.on('click', event => {
  channel.push('register_user', { user_name: name.val(), password: password.val() });
}
);

followbtn.on('click', event => {
  channel.push('subscribe', {sessionKey: session_key, userId: user_id, subscribeTo: followtxt.val()});
  followtxt.val('');
}
);

logoutbtn.on('click', event => {
  session_key = "";
  homepagediv.hide();
  signupdiv.show();
  password.val('');
  name.val('');
  searchhashtagtext.val('');
  searchusernametxt.val('');
  retweetusernametxt.val('');
  retweettxt.val('');
  followtxt.val('');
  list.innerHTML = "";
}
);


// channel.on('receive_tweet', payload => {
//   list.append(`<b>${payload.name || 'Celebrity'} tweeted : </b> ${payload.message}<br>`);
//   list.prop({scrollTop: list.prop("scrollHeight")});
// });

// channel.on('receive_retweet', payload => {
//   list.append(`<b>${payload.username1 || 'Celebrity'} retweeted ${payload.username2} tweet - </b> ${payload.message}<br>`);
//   list.prop({scrollTop: list.prop("scrollHeight")});
// });

channel.on('receive_response', payload => {
  list.append(`${payload.message}<br>`);
  list.prop({scrollTop: list.prop("scrollHeight")});
});

// Pradeep --START
channel.on("registration_result", payload => {
  console.log("Inside registration")
  console.log(payload)

  if(payload.result != "error"){
    homepagediv.show();
    signupdiv.hide();
    session_key = payload.session_key;
    user_id = name.val();
  }
  else{
    alert(payload.reason);
  }
})

channel.on("login_result", payload => {
  console.log("Inside login")
  console.log(payload)

  if(payload.result != "error"){
    homepagediv.show();
    signupdiv.hide();
    session_key = payload.session_key;
    user_id = name.val();
  }
  else{
    alert(payload.reason);
  }
})

channel.on("recent_feed", payload => {
  console.log("Inside recent feed")
  console.log(payload)
  list.empty();
  for(var i in payload["recent_feed"])
  {
    list.append(`<b>${payload["recent_feed"][i].fromUserId || 'Celebrity'}: </b> ${payload["recent_feed"][i].tweet} (Tweet ID: ${payload["recent_feed"][i].tweetId})<br>`);
    list.prop({scrollTop: list.prop("scrollHeight")}); 
  }
})

channel.on("search_mentions_result", payload => {
  console.log("Inside mention results")
  console.log(payload)

  for(var i in payload["tweetList"])
  {
    list.append(`<b>(@Mentions) ${payload["tweetList"][i].userId || 'Celebrity'}: </b> ${payload["tweetList"][i].tweet}<br>`);
    list.prop({scrollTop: list.prop("scrollHeight")}); 
  }
})

channel.on("search_hash_tag_result", payload => {
  console.log("Inside search hash tag")
  console.log(payload)

  for(var i in payload["tweetList"])
  {
    list.append(`<b>(Hashtag) ${payload["tweetList"][i].userId || 'Celebrity'}: </b> ${payload["tweetList"][i].tweet}<br>`);
    list.prop({scrollTop: list.prop("scrollHeight")}); 
  }
  // for (var key in payload) {
  //   if (payload.hasOwnProperty(key)) {
  //     list.append(`<b>${payload[key].userId || 'Celebrity'}: </b> ${payload[key].tweet}<br>`);
  //     list.prop({scrollTop: list.prop("scrollHeight")});
  //   }
  // }
})

channel.on("receive_tweet", payload => {
  console.log("Inside receive tweet")
  console.log(payload)
  if(payload.tweetFromUserId == payload.createrUserId){
    list.append(`<b>${payload.tweetFromUserId || 'Celebrity'} tweeted : </b> ${payload.tweet} (Tweet ID: ${payload.tweetId}) <br>`);
    list.prop({scrollTop: list.prop("scrollHeight")});
  }
  else{
    list.append(`<b>${payload.tweetFromUserId || 'Celebrity'} retweeted ${payload.createrUserId || 'Celebrity'}'s tweet: </b> ${payload.tweet} (Tweet ID: ${payload.tweetId}) <br>`);
    list.prop({scrollTop: list.prop("scrollHeight")});
  }
})

// Pradeep --END

channel.join()
.receive("ok", resp => { console.log("Joined successfully", resp) })
.receive("error", resp => { console.log("Unable to join", resp) })

export default socket
